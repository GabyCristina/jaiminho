<?php

    header("Location: app/controlador/controlador.php");

    ?>